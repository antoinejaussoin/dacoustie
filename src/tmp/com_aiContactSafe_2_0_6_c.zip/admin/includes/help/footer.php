﻿<?php
/**
 * @version     $Id$ 2.0.0 0
 * @package     Joomla
 * @copyright   Copyright (C) 2005 - 2008 Open Source Matters. All rights reserved.
 * @license     GNU/GPL, see LICENSE.php
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// the footer of the help will be added here
?>
<br />
<hr />
<div id="aiContactSafe_help_footer">
&copy;&nbsp;2009&nbsp;<a href="http://www.algis.ro/" target="_blank">Algis Info</a> - Software, Web Development & Web Hosting
</div>
