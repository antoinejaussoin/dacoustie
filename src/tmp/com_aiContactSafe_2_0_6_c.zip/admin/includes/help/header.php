﻿<?php
/**
 * @version     $Id$ 2.0.0 0
 * @package     Joomla
 * @copyright   Copyright (C) 2005 - 2008 Open Source Matters. All rights reserved.
 * @license     GNU/GPL, see LICENSE.php
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// the header of the help will be added here
?>
<div id="aiContactSafe_help_header">
<h3><?php echo JText::_( 'help__help' ); ?> aiContactSafe</h3>
</div>
